//
//  SettingContoller.swift
//  Stock
//
//  Created by zhiyuan li on 2017-07-29.
//  Copyright © 2017 zhiyuan li. All rights reserved.
//
import UIKit
class SettingController: UIViewController, UITabBarDelegate {
    
}
