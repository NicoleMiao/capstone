//
//  FVcontrollerViewController.swift
//  Stock
//
//  Created by Xin Lyu on 2017-09-27.
//  Copyright © 2017 zhiyuan li. All rights reserved.
//

import UIKit

class FVViewController: UIViewController {
    
    
    @IBOutlet weak var openc: UILabel!
    @IBOutlet weak var lowc: UILabel!
    @IBOutlet weak var highc: UILabel!
    @IBOutlet weak var avc: UILabel!
    @IBOutlet weak var wl: UILabel!
    @IBOutlet weak var wh: UILabel!
    @IBOutlet weak var vc: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
